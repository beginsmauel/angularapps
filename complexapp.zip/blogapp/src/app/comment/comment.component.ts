import { Observable, of, empty, fromEvent, from, interval } from 'rxjs';
import {
  delay,
  switchMapTo,
  concatAll,
  count,
  scan,
  withLatestFrom,
  share,
  switchMap,
  startWith,
  filter
} from 'rxjs/operators';
import { RemoteService } from './../remote.service';
import { Component, OnInit, OnChanges, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, Form, FormGroup, Validators} from '@angular/forms';
import { Blog}  from '../blog';
import {User} from '../user';


@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit, OnChanges, OnDestroy {

  names: string[];
  posts:  Blog[] = [];
  postSubscribe : any;
  users:  User[] = [];
  commentForm = this.fb.group({
    firstName : ['', Validators.required ]
   });

  constructor(private fb: FormBuilder, private remoteService: RemoteService) { this.names = []; }


   finished = false;

   ngOnInit(): void {

    // Blog Posts 
    this.postSubscribe =   this.remoteService.getRemoteBlogsAsync()
    .subscribe((resp: any) => {
      console.log(resp);
      resp.body.forEach(element => {
          this.posts.push(element)});
    });
    console.log(this.posts);

    // Users 
    let sam = this.remoteService.getRemoteUsers()
    .pipe(filter( (user: any) => user.username !== 'Bret'));

    sam.subscribe((res: any) => {
        res.forEach(element => {
          console.log(element);
          this.users.push(element);
        });
    });


    // Events

    this.remoteService.getRemoteEvents()
    .subscribe((resp: any) => {
      console.log(resp);
      resp.forEach(element => {
          console.log(element);
      });
    });


  }
  ngOnChanges(){



  }

  ngOnDestroy() {
    //this.postSubscribe.unsubscribe();
  }


  onSubmit(){
    console.log(this.commentForm.get("firstName").value);
    const blog: Blog = new Blog();
    blog.id = ''+ this.posts.length;
    blog.title= " Posting through api";
    blog.post = " Testing Post actions";

    this.remoteService.pushBlogToRemote(blog)
    .subscribe((resp: any) => {
      console.log(resp);
      console.log(resp.message);
    });
  }


}
