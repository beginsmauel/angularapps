import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BlogService {

  blogPosts : any[] = [
    {
      "id" : "123",
      "title" : "How to build a Angular App",
      "post"  : " In this post, we will see complete details to build an Angular App."
    },
    {
      "id" : "124",
      "title" : "How to build a Node Js App",
      "post"  : " Node Js is Server side Javascript App. we can built one REST API app "
    }
  ];

  constructor() {
    console.log(this.blogPosts);
   }

   getBlogPosts() : any[]{
     return this.blogPosts; 
   } 

   getBlog(id : string) : any[]{
    return this.blogPosts
              .filter(item => item.id == id)
              .reduce(blog => blog);
   }

   updateApprover(blog: any, id: string, approver: string){
    let data = blog;
    this.blogPosts = this.blogPosts.filter(obj => obj !== blog);
    blog.approvedBy = approver;
     this.blogPosts.push(blog);
   }

}
