import { element } from 'protractor';
import { Component, OnInit, Input, ElementRef, OnChanges } from '@angular/core';
import { randomBytes } from 'crypto';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent implements OnInit, OnChanges {
  collegeName  = "SACOE";
  col: string = "SACOE";
  location = 'Tiruchendur';
  newLocation = '';

  constructor() {
    this.collegeName = this.col;
   }

  ngOnInit(): void {
  }
   changeLocation  = (loc : string) =>{
    this.location = loc;
    this.collegeName = this.col + " - " + loc;
  };

  ngOnChanges(){
    console.log("value changed....");
  }


  updateCollege = () =>{
   this.collegeName = "Changed";
  }
}
