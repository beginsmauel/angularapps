import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';

@Component({
  selector: 'app-inline-blog',
  templateUrl: './inline-blog.component.html',
  styleUrls: ['./inline-blog.component.css']
})
export class InlineBlogComponent implements OnInit, OnChanges {

  approvedBy : string 

  @Input() 
  inlineSelectedBlog :any;

  @Output() 
  approvedPost = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }
  ngOnChanges() {
    
  }

  Approve(id : string ): void{
     this.approvedPost.emit({id :id, approvedBy : this.approvedBy });
     this.approvedBy = null;
     console.log("emit...");
  }

}
