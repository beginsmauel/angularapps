import { Component, OnChanges,OnInit, SimpleChanges, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnChanges, OnInit {
  title = 'Welcome to Blog Application';
  count = 0;

  @Input() selection: string;

  ngOnInit(){
    console.log('Init...');
  }


  ngOnChanges(changes: SimpleChanges) {
    for (let propName in changes) {  
       console.log(propName);
      //let change = changes[propName];
      //let curVal  = JSON.stringify(change.currentValue);
      //let prevVal = JSON.stringify(change.previousValue);
      // console.log(curVal);
      // console.log(prevVal);
    }

 }

}
