import { Injectable } from '@angular/core';
import {Blog} from './blog';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient,HttpResponse, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map , filter} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RemoteService {
  configURL = 'http://localhost:8080/api/blogs';
  constructor(private http: HttpClient) { }

   getRemoteUsers() {
      return this.http.get("http://jsonplaceholder.typicode.com/users");
   }

   getRemoteEvents() {
    return this.http.get("http://localhost:8282/events");
 }


   getRemoteBlogsAsync(): Observable<HttpResponse<Blog[]>> {
    return this.http.get<Blog[]>(
      this.configURL, { observe: 'response' });
  }


  pushBlogToRemote(blog: Blog) {
    return this.http.post(this.configURL,blog);
  }
}
