import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sacodePrefix'
})
export class SacodePrefixPipe implements PipeTransform {

  /*transform(value: string, ...args: string[]): string {
    return args!= null? args[0] + " " + value : "SACOE " + value;
  }*/

 transform(value: string, prefix: string): string {
    return prefix!= null? prefix + " " + value : "SACOE " + value;
  }
  
}
