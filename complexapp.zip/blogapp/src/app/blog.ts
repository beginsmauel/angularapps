import { Deserializable } from './deserialize.model';

export class Blog implements Deserializable{

    _id: string;
    post: string;
    title: string;
    id: string;
    __v   : number;

 deserialize(input: any) {
    Object.assign(this, input);
    return this;
 }

}
