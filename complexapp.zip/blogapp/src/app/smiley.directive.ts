import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[smiley]'
})
export class SmileyDirective {
    constructor(el: ElementRef) {
       el.nativeElement.style.color = 'green';
    }
}