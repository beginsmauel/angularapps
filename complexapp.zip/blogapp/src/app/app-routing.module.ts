import { CommentComponent } from './comment/comment.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponentComponent} from './list-component/list-component.component'
import { DetailComponentComponent} from './detail-component/detail-component.component'
import { PageNotFoundComponent}  from './page-not-found/page-not-found.component'
import { BindingComponent } from './binding/binding.component';

const routes: Routes = [
  { path : 'blogs', component : ListComponentComponent},
  { path: 'binding', component : BindingComponent },
  { path : 'blog/:id', component : DetailComponentComponent},
  { path : 'forms', component : CommentComponent},
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
