import { RemoteService } from './remote.service';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BlogService} from './blog.service'
import { ListComponentComponent } from './list-component/list-component.component';
import { DetailComponentComponent } from './detail-component/detail-component.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SmileyDirective} from './smiley.directive';
import { SacodePrefixPipe } from './sacode-prefix.pipe';
import { BindingComponent } from './binding/binding.component';
import { InlineBlogComponent } from './inline-blog/inline-blog.component';
import { CommentComponent } from './comment/comment.component';
import { ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';



@NgModule({
  declarations: [
    AppComponent,
    ListComponentComponent,
    DetailComponentComponent,
    PageNotFoundComponent,
    SmileyDirective,
    SacodePrefixPipe,
    BindingComponent,
    InlineBlogComponent,
    CommentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [BlogService, RemoteService],
  bootstrap: [AppComponent]
})
export class AppModule { }
