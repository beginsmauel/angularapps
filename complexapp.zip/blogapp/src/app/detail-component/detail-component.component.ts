//import { switchMap } from 'rxjs/operators';
import { Component, OnInit, OnDestroy , Input} from '@angular/core';
import {ActivatedRoute, Router, ParamMap} from '@angular/router';
import {BlogService} from '../blog.service'
//import { SmileyDirective} from '../smiley.directive';


@Component({
  selector: 'app-detail-component',
  templateUrl: './detail-component.component.html',
  styleUrls: ['./detail-component.component.css']
})
export class DetailComponentComponent implements OnInit, OnDestroy {
  
  selectedBlog : any; //Observable<any>
  selectedBlogSub : any;

  
  constructor(private route : ActivatedRoute,
    private router: Router,
    private blogService: BlogService) { 
      this.selectedBlog = null;
  }
//  @Input('hello') sam: any;



  ngOnInit(): void {
        let id = this.route.snapshot.paramMap.get('id');
        this.selectedBlog = this.blogService.getBlog(id);

        //this.selectedBlogSub = this.route.params.subscribe(params => {  
        //this.selectedBlog = this.blogService.getBlog(params["id"]);
        console.log("subscribe invoked");
        console.log( this.selectedBlog);

        //});
        if( this.selectedBlog == null){
         // this.router.navigate(["**"]);
        }
  }

  ngOnDestroy() {
      //this.selectedBlogSub.unsubscribe();
      console.log(" unsubscribe invoked");
  }
    
    /*this.selectedBlog = this.route.paramMap.pipe(
      switchMap((params: ParamMap) =>
        this.blogService.getBlog(params.get('id')))
    );*/


}
