import { Component, OnInit, Input } from '@angular/core';
import {BlogService} from '../blog.service'

@Component({
  selector: 'app-list-component',
  templateUrl: './list-component.component.html',
  styleUrls: ['./list-component.component.css']
})
export class ListComponentComponent implements OnInit {

  blogs : any[]
  SelectedBlog : any
  approvedBy : string;
  blogServiceIn : BlogService
 
  constructor(blogService : BlogService) {
       this.blogs = blogService.getBlogPosts();
       this.SelectedBlog = null;
       console.log(this.blogs);
       this.blogServiceIn = blogService;
   }
  ngOnInit(): void {
    
  }
  ngOnChanges(){

     this.blogs = this.blogServiceIn.getBlogPosts();
  }

  displayDetailInline(blog: any): any{
    console.log(blog);
    this.SelectedBlog = blog;
    
  }
  onApproved(data : any){
    console.log("received approvd blog");
    console.log(data);
    this.blogServiceIn.updateApprover(this.SelectedBlog,data.id,data.approvedBy);
    
  }

 

}
