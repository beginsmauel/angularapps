import { SacodePrefixPipe } from './sacode-prefix.pipe';

describe('SacodePrefixPipe', () => {
  it('create an instance', () => {
    const pipe = new SacodePrefixPipe();
    expect(pipe).toBeTruthy();
  });
});
