# Building a RESTful API in Node and Express

## Requirements

- Node and npm

## Installation

- Clone the repo: `git clone git@github.com:beginsmauel/backend-appnode-api`
- Install dependencies: `npm install`
- Start the server: `node server.js`

